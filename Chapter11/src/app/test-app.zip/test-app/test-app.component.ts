import { Component, OnInit } from '@angular/core';
import { TestAppService } from './test-app.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-test-app',
  templateUrl: './test-app.component.html',
  styleUrls: ['./test-app.component.css'],
  providers: [TestAppService]
})

export class TestAppComponent implements OnInit {
	constructor(private _testAppService: TestAppService) {}
	
	private values: string[] = ['New York', 'New Jersey', 'Dallas', 'Austin'];
	public myModel = "Testing E2e";
	public authorName = 'Sridhar';

	public publisherName = 'Packt';
	public afterClick = 'Element is not clicked';

	public hiPackt() {
    	return 'Hello ' + this.publisherName;
  	}

  	ngOnInit():any{
   		let authorList = this._testAppService.getAuthorCount();
	}

	public sendMail() {
		this.afterClick = 'Element is clicked';
	}

}
